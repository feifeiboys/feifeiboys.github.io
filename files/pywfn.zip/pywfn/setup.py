from setuptools import setup,find_packages

setup(
    name="hfv",
    version="1.0",
    description="python 波函数分析工具",
    author="石小飞",
    packages=find_packages()
)