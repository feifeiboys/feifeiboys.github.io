function gto(n,l,m,a,c,x,y,z)
    x^n*y^l*z^m
end

print(gto(1,1,1,1,1,1,2,3))