from .shell import Shell
print('init')
def runShell():
    shell=Shell()
    shell.home()