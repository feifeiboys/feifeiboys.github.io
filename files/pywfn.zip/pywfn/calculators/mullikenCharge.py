# 计算原子的muliken电荷

class Calculator:
    def __init__(self,mol):
        self.mol=mol


    