"""
老方法计算键级
"""


class Calculator:
    def __init__(self,mol:'Mol'):
        self.mol=mol





if __name__=='__main__':
    from ....pywfn.base import Mol